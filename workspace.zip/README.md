# DC Threshold Validator - POD 2.0 Extension

A custom POD 2.0 widget that monitors Data Collection inputs and applies visual threshold validation styling in SAP Digital Manufacturing.

## Overview

This widget automatically detects Data Collection input fields in your POD and validates entered values against their min/max thresholds. It provides immediate visual feedback:

- **Green styling** - Value is within the acceptable range
- **Orange styling** - Value is outside the acceptable range (below min or above max)

## Features

- **Automatic Input Detection**: Finds all Data Collection input fields in the POD
- **Real-time Validation**: Validates values as they are entered
- **Visual Row Styling**: Highlights entire rows based on validation status
- **Input Border Styling**: Changes input border color to indicate status
- **Status Icons**: Shows checkmark or warning icons next to inputs
- **Configurable Properties**: Enable/disable features as needed

## Installation

### 1. Create the Extension Package

Create a ZIP file containing:
```
extension.json
widget/
    DataCollectionThresholds.js
```

### 2. Upload to SAP Digital Manufacturing

1. Navigate to **Manage PODs 2.0** app
2. Go to **Extensions** tab
3. Click **Create**
4. Fill in:
   - **Name**: DCThresholdValidator (or your preferred name)
   - **Namespace**: `custom/dcthresholds`
   - **Source Code**: Upload the ZIP file
5. Click **Create**

### 3. Add Widget to POD

1. Open your POD in Design Mode
2. Find **"DC Threshold Validator"** in the plugin palette under **Custom Widgets** category
3. Drag and drop it onto your POD layout
4. Save the POD

## Configuration

| Property | Description | Default |
|----------|-------------|---------|
| Enabled | Enable or disable threshold validation | true |
| Show Status Icons | Show validation status icons next to inputs | true |
| Log to Console | Enable console logging for debugging | false |

## Visual Styling

### Valid (Within Limits)
- Row: Green gradient background with green left border
- Input: Green border with light green background
- Icon: Green checkmark

### Warning (Outside Limits)
- Row: Orange gradient background with orange left border
- Input: Orange border with light orange background
- Icon: Orange warning triangle

## How It Works

1. **Input Detection**: The widget polls the DOM for Data Collection input fields
2. **Threshold Extraction**: For each input, it extracts min/max values from:
   - Binding context data
   - Stored DC parameters from POD Context
3. **Live Validation**: Attaches live change listeners to inputs
4. **Visual Feedback**: Applies CSS styling based on validation results

## Supported Data Properties

The widget looks for threshold values in these properties:
- `minValue`, `maxValue`
- `lowerLimit`, `upperLimit`
- `minLimit`, `maxLimit`
- `lowerSpecificationLimit`, `upperSpecificationLimit`
- `minSpecLimit`, `maxSpecLimit`

## Technical Details

- **Module Path**: `custom/dcthresholds/widget/DataCollectionThresholds`
- **Type**: `custom.dcthresholds.widget.DataCollectionThresholds`
- **Base Class**: `sap/dm/dme/pod2/widget/Widget`
- **Category**: Custom Widgets

## File Structure

```
├── extension.json                      # Extension configuration
├── README.md                           # This file
└── widget/
    └── DataCollectionThresholds.js     # Widget implementation
```

## Dependencies

- SAP Digital Manufacturing POD 2.0
- SAPUI5 libraries (included in DM)

## Comparison with POD 1.0 Version

This POD 2.0 version is a port of the original `extendDataCollectionCapture` extension:

| Feature | POD 1.0 Version | POD 2.0 Version |
|---------|-----------------|-----------------|
| Architecture | Plugin Extension | Widget |
| Integration | Extends DC Entry Plugin | Standalone widget |
| Configuration | Code-based | POD Designer properties |
| Deployment | Extension Provider | Manage PODs 2.0 |

## Notes

- The widget panel can be collapsed to minimize space usage
- Enable "Log to Console" for debugging threshold detection issues
- The widget automatically re-validates when inputs change

## Version

1.0.0

## License

This extension is provided as-is for SAP Digital Manufacturing customization.